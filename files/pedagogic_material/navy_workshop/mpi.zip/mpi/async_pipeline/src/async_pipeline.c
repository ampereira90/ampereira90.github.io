#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>

void pipeline (int argc, char* argv[]) {
    int num_procs, my_rank;
    int msg;
    MPI_Status status;

    MPI_Init (&argc, &argv);

    MPI_Comm_size (MPI_COMM_WORLD, &num_procs);
    MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);

    if (my_rank == 0) {
        MPI_Send (&my_rank, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
    } else if (my_rank == num_procs - 1) {
        MPI_Recv (&msg, 1, MPI_INT, my_rank - 1, 0, MPI_COMM_WORLD, &status);
        printf ("Process %d received %d from %d\n", my_rank, msg, my_rank - 1);
    } else {
        MPI_Recv (&msg, 1, MPI_INT, my_rank - 1, 0, MPI_COMM_WORLD, &status);
        printf ("Process %d received %d from %d\n", my_rank - 1, msg, my_rank + 1);
        MPI_Send (&my_rank, 1, MPI_INT, my_rank + 1, 0, MPI_COMM_WORLD);
    }

    MPI_Finalize ();
}

// ************************************************
// * Async pipeline communication - async_pipeline
// * - modify the code to use assynchronous communication
// * - each process should print his rank along with the rank of its left process (msg)
// ************************************************

void async_pipeline (int argc, char* argv[]) {
    int num_procs, my_rank, send_rank, recv_rank;
    int msg;
    MPI_Request reqs[2];

    MPI_Init (&argc, &argv);

    MPI_Comm_size (MPI_COMM_WORLD, &num_procs);
    MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);
    
    // complete the code - calculate the rank to which the current process
    // will receive data from and send data to
    
    // ...
    
    // this may be useful for the code section above
    if (recv_rank < 0) recv_rank = MPI_PROC_NULL;

    // complete the code - send/recv the async messages and wait for all processes after

    if (my_rank != 0)
        printf ("Process %d received %d from %d\n", my_rank, msg, recv_rank);

    MPI_Finalize ();
}
