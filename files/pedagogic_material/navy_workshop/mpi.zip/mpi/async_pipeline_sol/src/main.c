#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>

void pipeline (int argc, char* argv[]);
void async_pipeline (int argc, char* argv[]);

int main (int argc, char* argv[]) {

    if (argc < 2) {
        printf ("The version of the code to run must be passed as argument:\n");
        printf ("> ./run.sh 1 -> run the regular pipeline\n");
        printf ("> ./run.sh 2 -> run the async pipeline\n");

        exit (0);
    }

    int v = atoi (argv[1]);

    switch (v) {
        case 1: pipeline (argc, argv); break;
        case 2: async_pipeline (argc, argv); break;
        
        default:
            printf ("Pass the correct version of the code to run as argument:\n");
            printf ("> ./run.sh 1 -> run the regular pipeline\n");
            printf ("> ./run.sh 2 -> run the async pipeline\n");
            break;
    }

    return 0;
}
