#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>

// ************************************************
// * Pipeline communication - pipeline1
// * - use 3 processes
// * - proc0 -> proc1 -> proc2
// * - send the msg (number 0), adding the proc rank to it
// * - print the intermediate stages of the message
// ************************************************

void pipeline1 (int argc, char* argv[]) {
    int num_procs, my_rank;
    int msg;
    MPI_Status status;

    MPI_Init (&argc, &argv);

    MPI_Comm_size (MPI_COMM_WORLD, &num_procs);
    MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);

    if (my_rank == 0) {
            msg = 0;
            MPI_Send (&msg, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
            printf ("Sending msg %d from %d to %d\n", msg, my_rank, 1);
    } else if (my_rank == 1) {
            // complete the code
    } else if (my_rank == 2) {
            // complete the code
    }

    MPI_Finalize ();
}

// ************************************************
// * Pipeline communication - pipeline2
// * - generalize for N processes
// ************************************************

void pipeline2 (int argc, char* argv[]) {
    int num_procs, my_rank;
    int msg;
    MPI_Status status;

    MPI_Init (&argc, &argv);

    MPI_Comm_size (MPI_COMM_WORLD, &num_procs);
    MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);

    // complete the code

    MPI_Finalize ();
}

// ************************************************
// * EXTRA: Pipeline communication - pipeline3
// * - modify the code to send an arbitrary amount of messages
// * - proc0 broadcasts the amount of messages
// * - intermediate procs should receive and send each individually
// ************************************************

void pipeline3 (int argc, char* argv[]) {
    int num_procs, my_rank;
    int msg, num_msgs;
    MPI_Status status;

    MPI_Init (&argc, &argv);

    MPI_Comm_size (MPI_COMM_WORLD, &num_procs);
    MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);

    if (my_rank == 0)  num_msgs = 4;
   
    // complete the code

    MPI_Finalize ();
}
