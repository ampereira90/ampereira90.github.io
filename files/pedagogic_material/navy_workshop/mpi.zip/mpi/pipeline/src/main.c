#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>

void pipeline1 (int argc, char* argv[]);
void pipeline2 (int argc, char* argv[]);
void pipeline3 (int argc, char* argv[]);

int main (int argc, char* argv[]) {

    // pipeline1 (argc, argv);
    // pipeline2 (argc, argv);
    pipeline3 (argc, argv);

    return 0;
}
