#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <mpi.h>


void max_random () {
    float my_random, curr_random;

    srand (time (NULL));

    for (int i = 0; i < 100; i++) {
        curr_random = rand () / (float) RAND_MAX;
        if (i == 0 || my_random < curr_random) {
            my_random = curr_random;
        }
    }

    printf ("Highest sequential value is %f\n\n", my_random);
}

// ************************************************
// * Gather/reduction communication - max_random1
// * - each process should generate a subset of the numbers
// * - perform a reduction to determine the highest of the numbers 
// * - proc0 prints the final value
// * - each process should also print its highest value for debugging purposes
// ************************************************

void max_random1 (int argc, char* argv[]) {
    int num_procs, my_rank;
    float my_random, curr_random, overall_random;

    MPI_Init (&argc, &argv);

    MPI_Comm_size (MPI_COMM_WORLD, &num_procs);
    MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);

    srand (time (NULL) + my_rank);

    // complete the code

    printf ("Highest value of proc %d is %f\n", my_rank, my_random);

    // complete the code

    if (my_rank == 0)
        printf ("Highest overall value is %f\n", overall_random);

    MPI_Finalize ();
}
