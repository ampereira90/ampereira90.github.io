#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>

void max_random ();
void max_random1 (int argc, char* argv[]);

int main (int argc, char* argv[]) {

    if (argc < 2) {
        printf ("The version of the code to run must be passed as argument:\n");
        printf ("> ./run.sh 1 -> run the sequential max_random\n");
        printf ("> ./run.sh 2 -> run the parallel max_random1\n");

        exit (0);
    }

    int v = atoi (argv[1]);

    switch (v) {
        case 1: max_random (); break;
        case 2: max_random1 (argc, argv); break;
        
        default:
            printf ("Pass the correct version of the code to run as argument:\n");
            printf ("> ./run.sh 1 -> run the sequential max_random\n");
            printf ("> ./run.sh 2 -> run the parallel max_random1\n");
            break;
    }

    return 0;
}
