#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>

#define ARRAY_SIZE 1000000
#define THRESHOLD 0.5

void master_worker_filter (float array[], int array_size, float f, int my_rank, int num_procs);
void filter (float array[], int array_size, float f);

float *init_array (int size) {
    float *arr = (float *) malloc (size * sizeof (float));

    for (int i = 0; i < size; i++) {
        arr[i] = rand () / (float) RAND_MAX;
    }

    return arr;
}

int main (int argc, char* argv[]) {
    float *a = NULL;
    int num_procs, my_rank;
    MPI_Init (&argc, &argv);

    MPI_Comm_size (MPI_COMM_WORLD, &num_procs);
    MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);

    if (my_rank == 0) {
        a = init_array (ARRAY_SIZE);
        filter (a, ARRAY_SIZE, THRESHOLD);
    }

    // synchronization, ensures that array is initalized before
    // all procs continue execution
    MPI_Barrier (MPI_COMM_WORLD);

    master_worker_filter (a, ARRAY_SIZE, THRESHOLD, my_rank, num_procs);

    MPI_Finalize ();

    return 0;
}
