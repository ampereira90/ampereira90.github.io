#include <stdlib.h>
#include <stdio.h>
#include <mpi.h>

#define TAG_ASK_FOR_JOB 1
#define TAG_JOB_DATA 2
#define TAG_STOP 3

void filter (float array[], int array_size, float f) {
    float sum = 0.0;

    for (int i = 0; i < array_size; i++) {
        if (array[i] > f) sum += array[i];
    }

    printf ("Expected sum of values above %.1f: %f\n\n", f, sum);
}

int check_workers (int wk[], int nprocs) {
    int sum = 0;
    for (int i = 0; i < nprocs; i++)
        sum += wk[i];

    return sum;
}

// ************************************************
// * Async pipeline communication - async_pipeline
// * - MPI initalization already performed in main.c
// * - array is only filled for proc0
// * - dynamic distribution of data (upon request from worker)
// *    - send a subset of the array each time
// ************************************************

void master_worker_filter (float array[], int array_size, float f, int my_rank, int num_procs) {
    float sum = 0.0, final_sum = 0.0;
    int stop = 0;
    int data_chunk = 100;    // use only powers of 10 for simplicity
    MPI_Status status, status2;

    if (my_rank == 0) {
        // master process
        int current_it = 0;
        int dummy_msg = 0;
        int *active_workers = (int *) malloc (num_procs * sizeof (int));

        // master stores the state of each worker
        // 1 - active; 0 - stopped
        // careful, master isnt a worker
        for (int i = 0; i < num_procs-1; i++) active_workers[i] = 1;

        // master distributes data while there's still active workers
        while (check_workers (active_workers, num_procs-1) > 0) {
            // wait for any incomming message
            MPI_Probe (MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            // store rank of receiver into worker_rank
            int worker_rank = status.MPI_SOURCE;

            if (status.MPI_TAG == /* ? */) {
                // accepts and unblocks the probed communication
                MPI_Recv (&dummy_msg, 1, MPI_INT, worker_rank, TAG_ASK_FOR_JOB, MPI_COMM_WORLD, &status2);

                if (/* ? */) {
                    // complete the code
                } else {
                    // send stop msg to worker
                    // use the tag to specify that behavior (see the #defines above)
                    MPI_Send (&dummy_msg, 1, MPI_INT, /* ? */);
                    
                    active_workers[worker_rank-1] = 0;
                }
            }
        }
    } else {
        // worker processes
        float *partial_array = (float *) malloc (data_chunk * sizeof (float));

        do {
            // request new batch of data
            MPI_Send (&sum, 1, MPI_INT, 0, TAG_ASK_FOR_JOB, MPI_COMM_WORLD);
            // probe for a response
            MPI_Probe (0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

            // the tag informs about the type of response from master
            // check it!
            if (/* ? */) {
                // Retrieve job data from master into partial_array
                // process the algorithm itself
                
                // complete the code 
                }
            } else {
                // We got a stop message we have to retrieve it by using MPI_Recv
                // complete the code
                
                stop = 1;
            }
        } while (stop == 0);
    }

    // reduction of partial results
    // complete the code 

    if (my_rank == 0)
        printf ("Parallel sum of values above %.1f: %f\n", f, final_sum);
}
