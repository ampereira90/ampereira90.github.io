#/bin/bash
#SBATCH -J master_worker      # Job name
#SBATCH -o master_worker.o%j  # Name of stdout output file (%j expands to jobId)
#SBATCH -p base          # Queue name
#SBATCH -N <num>             # Total number of nodes requested (16 cores/node)
#SBATCH -n <num>         # Total number of mpi tasks requested
#SBATCH -t 00:10:00      # Run time (hh:mm:ss)
#SBATCH -A TR0012022     # <-- Allocation name to charge job against

mpirun ./bin/master_worker
