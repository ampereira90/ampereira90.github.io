#include <stdlib.h>
#include <stdio.h>
#include <omp.h>

double pi_integration (long);
double pi_integration_parallel_v1 (long);
double pi_integration_parallel_v2 (long);

int main (int argc, char* argv[]) {
    long num_steps = 1000000;
    double pi;

    if (argc < 2) {
        printf ("The version of the code to run must be passed as argument:\n");
        printf ("> ./run.sh 1 -> run the sequential pi integration\n");
        printf ("> ./run.sh 2 -> run the parallel pi integration v1\n");
        printf ("> ./run.sh 3 -> run the parallel pi integration v2\n");
        exit (0);
    }

    int v = atoi (argv[1]);

    // start measuring the parallel section execution time
    double begin = omp_get_wtime ();

    switch (v) {
        case 1: pi = pi_integration (num_steps); break;
        case 2: pi = pi_integration_parallel_v1 (num_steps); break;
        case 3: pi = pi_integration_parallel_v2 (num_steps); break;
        
        default:
            printf ("Pass the correct version of the code to run as argument:\n");
            printf ("> ./run.sh 1 -> run the sequential pi integration\n");
            printf ("> ./run.sh 2 -> run the parallel pi integration v1\n");
            printf ("> ./run.sh 3 -> run the parallel pi integration v2\n");
            break;
    }

    double end = omp_get_wtime ();

    printf ("Approximate value of pi: %.17g\n", pi);
    printf ("\nExecution time of the pi calculation: %lf s\n", (end - begin));

    return 0;
}
