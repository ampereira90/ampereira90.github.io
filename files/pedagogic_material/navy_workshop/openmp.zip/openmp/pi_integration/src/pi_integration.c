#include <omp.h>
#define NUMBER_OF_THREADS 4

double pi_integration (long num_steps) {
    int i; 
    double x, pi, sum = 0.0;
    double step = 1.0 / (double) num_steps;
    
    for (i = 0; i < num_steps; i++) {
        x = (i + 0.5) * step;
        sum = sum + 4.0 / (1.0 + x * x);
    }
    
    pi = step * sum;

    return pi;
}

// ************************************************
// * Simple parallelization v1
// * - using pragma parallel omp and parallel for
// * - automatic loop distribution among threads
// * - privatization of specific variables
// * - manual sequential reduction of sum
// ************************************************
double pi_integration_parallel_v1 (long num_steps) {
    // Complete the code
}

// ************************************************
// * Simple parallelization v2
// * - using pragma parallel omp and parallel for
// * - automatic loop distribution among threads
// * - automatic pararell reduction of sum
// ************************************************
double pi_integration_parallel_v2 (long num_steps) {
    // Complete the code
}
