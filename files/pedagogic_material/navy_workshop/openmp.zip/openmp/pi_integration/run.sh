#/bin/bash
#SBATCH -J pi_integration      # Job name
#SBATCH -o pi_integration.o%j  # Name of stdout output file (%j expands to jobId)
#SBATCH -p base          # Queue name
#SBATCH -N 1             # Total number of nodes requested (16 cores/node)
#SBATCH -t 00:10:00      # Run time (hh:mm:ss)
#SBATCH -A TR0012022     # <-- Allocation name to charge job against

./bin/pi_integration $1
