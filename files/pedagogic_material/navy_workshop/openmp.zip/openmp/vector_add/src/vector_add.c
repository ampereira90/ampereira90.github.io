#include <omp.h>
#define NUMBER_OF_THREADS 4

int* vector_add (int array1[], int array2[], int size) {
    // allocates space to store the output of the add
    int* out = (int*) malloc (size * sizeof (int));

    for (int i = 0; i < size; i++)
        out[i] = array1[i] + array2[i];

    return out;
}

// ************************************************
// * Simple parallelization v1
// * - using only pragma parallel omp
// * - manual data distribution among threads
// ************************************************
int* vector_add_parallel_v1 (int array1[], int array2[], int size) {
    // Complete the code
}

// ************************************************
// * Simple parallelization v2
// * - using only pragma parallel omp
// * - automatic loop distribution among threads
// ************************************************
int* vector_add_parallel_v2 (int array1[], int array2[], int size) {
    // Complete the code
}

// ************************************************
// * Simple parallelization v3
// * - using only pragma parallel omp
// * - automatic loop distribution among threads
// ************************************************
int* vector_add_parallel_v3 (int array1[], int array2[], int size) {
    // Complete the code
}
