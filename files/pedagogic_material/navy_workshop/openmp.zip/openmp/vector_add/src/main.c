#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <omp.h>

int partial_sum = 0;

int* vector_add (int array1[], int array2[], int size);
int* vector_add_parallel_v1 (int array1[], int array2[], int size);
int* vector_add_parallel_v2 (int array1[], int array2[], int size);

int* init_array (int size) {
    int *array = (int*) malloc (size * sizeof (int));

    srand (time (NULL));

    for (int i = 0; i < size; i++) {
        array[i] = rand ();
        partial_sum += array[i];
    }

    return array;
}

void validate_result (int res[], int size) {
    int sum = 0;

    for (int i = 0; i < size; i++)
        sum += res[i];

    if (partial_sum == sum)
        printf ("Vector addition was successful\n");
    else
        printf ("Vector addition calculated wrong output vector\n");
}

int main (int argc, char* argv[]) {
    int size = 1000000;
    int *array1 = init_array (size);   
    int *array2 = init_array (size);
    int* out_array;

    if (argc < 2) {
        printf ("The version of the code to run must be passed as argument:\n");
        printf ("> ./run.sh 1 -> run the sequential vector_add\n");
        printf ("> ./run.sh 2 -> run the parallel vector_add v1\n");
        printf ("> ./run.sh 3 -> run the parallel vector_add v2\n");
        exit (0);
    }

    int v = atoi (argv[1]);

    // start measuring the parallel section execution time
    double begin = omp_get_wtime ();

    switch (v) {
        case 1: out_array = vector_add (array1, array2, size); break;
        case 2: out_array = vector_add_parallel_v1 (array1, array2, size); break;
        case 3: out_array = vector_add_parallel_v2 (array1, array2, size); break;
        
        default:
            printf ("Pass the correct version of the code to run as argument:\n");
            printf ("> ./run.sh 1 -> run the sequential vector_add\n");
            printf ("> ./run.sh 2 -> run the parallel vector_add v1\n");
            printf ("> ./run.sh 3 -> run the parallel vector_add v2\n");
            break;
    }

    double end = omp_get_wtime ();

    validate_result (out_array, size);

    printf ("\nExecution time of the vector addition: %lf s\n", (end - begin));

    return 0;
}
