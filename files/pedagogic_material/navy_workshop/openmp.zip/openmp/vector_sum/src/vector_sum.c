#include <omp.h>
#define NUMBER_OF_THREADS 4

int vector_sum (int array[], int size) {
    int sum = 0.0;

    for (int i = 0; i < size; i++)
        sum += array[i];

    return sum;
}

// ************************************************
// * Simple parallelization v1
// * - using only pragma parallel omp
// * - manual sequential reduction of sum
// * - critical access to shared data
// ************************************************
int vector_sum_parallel_v1 (int array[], int size) {
    // Complete the code
}

// ************************************************
// * Simple parallelization v2
// * - using only pragma parallel omp
// * - automatic loop distribution among threads
// * - manual sequential reduction of sum
// ************************************************
int vector_sum_parallel_v2 (int array[], int size) {
    // Complete the code
}

// ************************************************
// * Simple parallelization v3
// * - using only pragma parallel omp
// * - automatic loop distribution among threads
// * - automatic pararell reduction of sum
// ************************************************
int vector_sum_parallel_v3 (int array[], int size) {
    // Complete the code
}
