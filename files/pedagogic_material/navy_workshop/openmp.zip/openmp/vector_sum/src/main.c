#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <omp.h>

int result;

int vector_sum (int array[], int size);
int vector_sum_parallel_v1 (int array[], int size);
int vector_sum_parallel_v2 (int array[], int size);
int vector_sum_parallel_v3 (int array[], int size);

int* init_array (int size) {
    int *array = (int*) malloc (size * sizeof (int));
    result = 0;

    srand (time (NULL));

    for (int i = 0; i < size; i++) {
        array[i] = rand ();
        result += array[i];
    }

    return array;
}

int main (int argc, char* argv[]) {
    int size = 1000000;
    int *array = init_array (size);
    int sum;

    if (argc < 2) {
        printf ("The version of the code to run must be passed as argument:\n");
        printf ("> ./run.sh 1 -> run the sequential vector_sum\n");
        printf ("> ./run.sh 2 -> run the parallel vector_sum v1\n");
        printf ("> ./run.sh 3 -> run the parallel vector_sum v2\n");
        printf ("> ./run.sh 3 -> run the parallel vector_sum v3\n");
        exit (0);
    }

    int v = atoi (argv[1]);

    // start measuring the parallel section execution time
    double begin = omp_get_wtime ();

    switch (v) {
        case 1: sum = vector_sum (array, size); break;
        case 2: sum = vector_sum_parallel_v1 (array, size); break;
        case 3: sum = vector_sum_parallel_v2 (array, size); break;
        case 4: sum = vector_sum_parallel_v3 (array, size); break;
        
        default:
            printf ("Pass the correct version of the code to run as argument:\n");
            printf ("> ./run.sh 1 -> run the sequential vector_sum\n");
            printf ("> ./run.sh 2 -> run the parallel vector_sum v1\n");
            printf ("> ./run.sh 3 -> run the parallel vector_sum v2\n");
            printf ("> ./run.sh 3 -> run the parallel vector_sum v3\n");
            break;
    }

    double end = omp_get_wtime ();

    printf ("Expected result: %d\n", result);
    printf ("Actual result: %d\n", sum);
    printf ("\nExecution time of the vector sum: %lf s\n", (end - begin));

    return 0;
}
