#/bin/bash
#SBATCH -J vector_sum      # Job name
#SBATCH -o vector_sum.o%j  # Name of stdout output file (%j expands to jobId)
#SBATCH -p base          # Queue name
#SBATCH -N 1             # Total number of nodes requested (16 cores/node)
#SBATCH -t 00:10:00      # Run time (hh:mm:ss)
#SBATCH -A TR0012022     # <-- Allocation name to charge job against

export OMP_NUM_THREADS=4

./bin/vector_sum $1
